# Sump Monitor for Home Assistant

A HACS-style custom integration based on oester/sump_monitor, redesigned for multiple independent sump pumps. Each configured pump is represented as a Home Assistant device; runtime/history is stored by the integration instead of requiring helper entities.

## Install
Copy `custom_components/sump_monitor` into `/config/custom_components/`, restart Home Assistant, then add **Sump Monitor** from Settings → Devices & services → Add Integration.

See `docs/CONFIGURATION.md` for configuration and migration notes.
